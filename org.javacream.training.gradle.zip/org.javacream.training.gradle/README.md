# org.javacream.training.gradle

1. Install Gradle

   1. Follow the instructions provided by https://docs.gradle.org/current/userguide/installation.html
   2. set Variables
      1. setx GRADLE_HOME c:\_training\tools\gradle-4.10.2
      2. setx Path "%Path%;c:\_training\tools\gradle-4.10.2\bin"
      3. check: gradle -version

2. Install Intellij Community Edition

Follow the instructions provided by https://www.jetbrains.com/idea/download
