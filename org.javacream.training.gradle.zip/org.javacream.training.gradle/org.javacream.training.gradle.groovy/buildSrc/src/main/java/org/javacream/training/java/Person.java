package org.javacream.training.java;

public class Person{
	private String lastname;
	private String firstname;
	private Integer height;
	private Long id;
	
	public Person(String lastname, String firstname, Integer height, Long id){
		this.lastname = lastname;
		this.firstname = firstname;
		this.height = height;
		this.id = id;
	}
	
	//Everything else: IDE Generate Source...
		
}